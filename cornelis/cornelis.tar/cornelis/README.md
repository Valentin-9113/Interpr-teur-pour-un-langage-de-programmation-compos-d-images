# Comportement attendu des programmes :

- 99bottles.ppm : affiche les paroles de la chanson "99bottles of beer on the wall"

- adder.ppm : prend en entrée deux entiers et affiche leur somme

- alpha.ppm : affiche les lettres de a à z

- cowsay.ppm : prend en entrée une ligne de texte et affiche une vache qui répète cette ligne

- euclide.ppm : prend en entrée deux entiers et affiche leur PGCD

- fact.ppm : prend en entrée un entier et affiche sa factorielle

- hw2.ppm : affiche "Hello, world!"

- hw3.ppm : affiche "Hello, world!"

- hw4.ppm : affiche "Hello, world!"

- mondrian.ppm : affiche "Hello, world!"

- Piet_hello.ppm : affiche "Hello, world!" (sans retour à la ligne)

- pietquest.ppm : propose un petit jeu

- pi.ppm : calcul une valeur approximative de pi

- power.ppm : prend en entrée deux entiers et affiche le premier à la puissance le second

- tetris.ppm : affiche "Tetris" sans retour à la ligne. (À noter : les blocs ont tous une forme de pièce en Tetris.)
